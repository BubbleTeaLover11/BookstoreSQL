<h1>BookstoreSQL</h1>

<h2>CS 340 Group Project, BookStore for William Chen and Patrick Kim.</h2>

<h3>Works Cited</h3>
<p>This project adapts code from: <a href = https://github.com/osu-cs340-ecampus/flask-starter-app?tab=readme-ov-file.>CS 340 Flask Starter</a><p>

<p>The adapted code can be found in the database folder. As such, the only use of its implementation is within the app.py file. Furthermore, this code aims to provide a connection to our MySQL database to help faciliate CRUD operations on our MySQL database without having to implement a novel function to connect to said database.</p>